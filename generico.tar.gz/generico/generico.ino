

#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>


// Replace with your network credentials
const char* ssid = "TPLINK";
const char* password = "gregorio@2012";

const char* PARAM_INPUT_1 = "output";
const char* PARAM_INPUT_2 = "state";

// Create AsyncWebServer object on port 80
AsyncWebServer server(80);

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html>
<head>
  <title>ESP Web Server</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="data:,">
  <style>
    html {font-family: Arial; display: inline-block; text-align: center;}
    h2 {font-size: 3.0rem;}
    p {font-size: 3.0rem;}
    body {max-width: 600px; margin:0px auto; padding-bottom: 25px;}
    .switch {position: relative; display: inline-block; width: 120px; height: 68px} 
    .switch input {display: none}
    .slider {position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; border-radius: 6px}
    .slider:before {position: absolute; content: ""; height: 52px; width: 52px; left: 8px; bottom: 8px; background-color: #fff; -webkit-transition: .4s; transition: .4s; border-radius: 3px}
    input:checked+.slider {background-color: #b30000}
    input:checked+.slider:before {-webkit-transform: translateX(52px); -ms-transform: translateX(52px); transform: translateX(52px)}
  </style>
</head>
<body>
  <h2>ESP Web Server</h2>
  %BUTTONPLACEHOLDER%
<script>function toggleCheckbox(element) {
  var xhr = new XMLHttpRequest();
  if(element.checked){ xhr.open("GET", "/update?output="+element.id+"&state=1", true); }
  else { xhr.open("GET", "/update?output="+element.id+"&state=0", true); }
  xhr.send();
}
</script>
</body>
</html>
)rawliteral";

// Replaces placeholder with button section in your web page
String processor(const String& var){
  //Serial.println(var);
  if(var == "BUTTONPLACEHOLDER"){
    String buttons = "";
    buttons += "<h4>Output - GPIO 2</h4><label class=\"switch\"><input type=\"checkbox\" onchange=\"toggleCheckbox(this)\" id=\"2\" " + outputState(2) + "><span class=\"slider\"></span></label>";
    buttons += "<h4>Output - GPIO 4</h4><label class=\"switch\"><input type=\"checkbox\" onchange=\"toggleCheckbox(this)\" id=\"4\" " + outputState(4) + "><span class=\"slider\"></span></label>";
    buttons += "<h4>Output - GPIO 33</h4><label class=\"switch\"><input type=\"checkbox\" onchange=\"toggleCheckbox(this)\" id=\"33\" " + outputState(33) + "><span class=\"slider\"></span></label>";
    return buttons;
  }
  return String();
}

String outputState(int output){
  if(digitalRead(output)){
    return "checked";
  }
  else {
    return "";
  }
}

void setup(){
  // Serial port for debugging purposes
  Serial.begin(115200);

  pinMode(2, OUTPUT);
  digitalWrite(2, LOW);
  pinMode(4, OUTPUT);
  digitalWrite(4, LOW);
  pinMode(33, OUTPUT);
  digitalWrite(33, LOW);
  
  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi..");
  }

  // Print ESP Local IP Address
  Serial.println(WiFi.localIP());

  // Route for root / web page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send_P(200, "text/html", index_html, processor);
  });

  // Send a GET request to <ESP_IP>/update?output=<inputMessage1>&state=<inputMessage2>
  server.on("/update", HTTP_GET, [] (AsyncWebServerRequest *request) {
    String inputMessage1;
    String inputMessage2;
    // GET input1 value on <ESP_IP>/update?output=<inputMessage1>&state=<inputMessage2>
    if (request->hasParam(PARAM_INPUT_1) && request->hasParam(PARAM_INPUT_2)) {
      inputMessage1 = request->getParam(PARAM_INPUT_1)->value();
      inputMessage2 = request->getParam(PARAM_INPUT_2)->value();
      digitalWrite(inputMessage1.toInt(), inputMessage2.toInt());
    }
    else {
      inputMessage1 = "No message sent";
      inputMessage2 = "No message sent";
    }
    Serial.print("GPIO: ");
    Serial.print(inputMessage1);
    Serial.print(" - Set to: ");
    Serial.println(inputMessage2);
    request->send(200, "text/plain", "OK");
  });

  // Start server
  server.begin();
}

void loop() {

}



//
//#include "Arduino.h"
//#include "FS.h"
//#include "LittleFS.h"
//
//#define LITTLEFS LittleFS
//
//typedef struct {
//  uint8_t activar;
//  uint8_t horas;
//  uint8_t minutos;
//  char weekDays[8];
//  uint8_t output;
//  uint8_t action;
//} Timers;
//
//
//uint8_t total_tmrs = 10;
//
//
//void setup(){
//  Serial.begin(115200);
//
//  delay(500);
//
//  Serial.println(F("Inizializing FS..."));
//  if (LITTLEFS.begin()) {
//    Serial.println(F("done."));
//  } else {
//    Serial.println(F("fail."));
//  }
//
//  File testFile = LITTLEFS.open(F("/timers.txt"), "r+");
//
//  // Lee a instância a ser alterada
//  Timers tmr = {};
//
//  strncpy( tmr.weekDays, "1000001", sizeof(tmr.weekDays) );
//
//  for (uint8_t i = 0; i < total_tmrs; i++) {
//    tmr.horas = i;
//    testFile.seek(i * sizeof(tmr), SeekSet);
//    testFile.write( (uint8_t*)&tmr, sizeof(tmr));
//  }
// testFile.close();
//
//
//  File testFileR = LITTLEFS.open(F("/timers.txt"), "r");
//
//  // Lee a instância a ser alterada
//  Timers tmrR = {};
//
//  
//  for (uint8_t i = 0; i < total_tmrs; i++) {   
//    testFileR.seek(i * sizeof(tmrR), SeekSet);
//    testFileR.read((uint8_t*)&tmrR, sizeof(tmrR));
//
//    Serial.print(String(tmrR.activar));
//    Serial.print(", ");
//    Serial.print(String(tmrR.horas));
//    Serial.print(":");
//    Serial.print(String(tmrR.minutos));
//    Serial.print(", ");
//    Serial.print(String(tmrR.weekDays));
//    Serial.print(", ");
//    Serial.print(String(tmrR.output));
//    Serial.print(", ");
//    Serial.println(String(tmrR.action));
//  }
// testFileR.close();
//
//}
//
//
//  
//void loop(){
//
//}





//
//#include "FS.h"
//#include <SPIFFS.h>
//
//
//typedef struct {
//  uint8_t activar;
//  uint8_t horas;
//  uint8_t minutos;
//  char weekDays[8];
//  uint8_t output;
//  uint8_t action;
//} Timers;
//
//
//uint8_t total_tmrs = 9;
//
//
//void setup() {
//  Serial.begin(115200);
//  delay(500);
//  Serial.println("");
//
//
//   // Initialize SPIFFS
//  if (!SPIFFS.begin()) {
//    Serial.println("An Error has occurred while mounting SPIFFS");
//    return;
//  }
//
//  
//  // Abre o arquivo para Leitura + Escritura (r+)
//  File myFileW = SPIFFS.open("/timers.txt", "r+");
//
//  // Lee a instância a ser alterada
//  Timers tmr = {};
//
//  strncpy( tmr.weekDays, "1000001", sizeof(tmr.weekDays) );
//
//  for (uint8_t i = 0; i < total_tmrs; i++) {
//    tmr.horas = i;
//    myFileW.seek(i * sizeof(tmr), SeekSet);
//    myFileW.write( (uint8_t*)&tmr, sizeof(tmr));
//  }
//
//  myFileW.close();
//
//
//
//
//  File myFileR = SPIFFS.open("/timers.txt", "r");
//
//  for (uint8_t i = 0; i < total_tmrs; i++) {
//
//    uint8_t offset = i;
//
//    Timers tmr = {};
//
//    uint16_t addr = (offset * sizeof(tmr));
//    myFileR.seek(i * sizeof(tmr), SeekSet);
//    myFileR.read((uint8_t*)&tmr, sizeof(tmr));
//
//    Serial.print(String(tmr.activar));
//    Serial.print(", ");
//    Serial.print(String(tmr.horas));
//    Serial.print(":");
//    Serial.print(String(tmr.minutos));
//    Serial.print(", ");
//    Serial.print(String(tmr.weekDays));
//    Serial.print(", ");
//    Serial.print(String(tmr.output));
//    Serial.print(", ");
//    Serial.println(String(tmr.action));
//  }
//
//   myFileR.close();
//
//}
//
//
//void loop() {
//
//}


//
//void listDir(fs::FS &fs, const char * dirname, uint8_t levels){
//    Serial.printf("Listing directory: %s\n", dirname);
//
//    File root = fs.open(dirname);
//    if(!root){
//        Serial.println("Failed to open directory");
//        return;
//    }
//    if(!root.isDirectory()){
//        Serial.println("Not a directory");
//        return;
//    }
//
//    File file = root.openNextFile();
//    while(file){
//        if(file.isDirectory()){
//            Serial.print("  DIR : ");
//            Serial.print (file.name());
//            time_t t= file.getLastWrite();
//            struct tm * tmstruct = localtime(&t);
//            Serial.printf("  LAST WRITE: %d-%02d-%02d %02d:%02d:%02d\n",(tmstruct->tm_year)+1900,( tmstruct->tm_mon)+1, tmstruct->tm_mday,tmstruct->tm_hour , tmstruct->tm_min, tmstruct->tm_sec);
//            if(levels){
//                listDir(fs, file.path(), levels -1);
//            }
//        } else {
//            Serial.print("  FILE: ");
//            Serial.print(file.name());
//            Serial.print("  SIZE: ");
//            Serial.print(file.size());
//            time_t t= file.getLastWrite();
//            struct tm * tmstruct = localtime(&t);
//            Serial.printf("  LAST WRITE: %d-%02d-%02d %02d:%02d:%02d\n",(tmstruct->tm_year)+1900,( tmstruct->tm_mon)+1, tmstruct->tm_mday,tmstruct->tm_hour , tmstruct->tm_min, tmstruct->tm_sec);
//        }
//        file = root.openNextFile();
//    }
//}
//
//void createDir(fs::FS &fs, const char * path){
//    Serial.printf("Creating Dir: %s\n", path);
//    if(fs.mkdir(path)){
//        Serial.println("Dir created");
//    } else {
//        Serial.println("mkdir failed");
//    }
//}
//
//void removeDir(fs::FS &fs, const char * path){
//    Serial.printf("Removing Dir: %s\n", path);
//    if(fs.rmdir(path)){
//        Serial.println("Dir removed");
//    } else {
//        Serial.println("rmdir failed");
//    }
//}
//
//void readFile(fs::FS &fs, const char * path){
//    Serial.printf("Reading file: %s\n", path);
//
//    File file = fs.open(path);
//    if(!file){
//        Serial.println("Failed to open file for reading");
//        return;
//    }
//
//    Serial.print("Read from file: ");
//    while(file.available()){
//        Serial.write(file.read());
//    }
//    file.close();
//}
//
//void writeFile(fs::FS &fs, const char * path, const char * message){
//    Serial.printf("Writing file: %s\n", path);
//
//    File file = fs.open(path, FILE_WRITE);
//    if(!file){
//        Serial.println("Failed to open file for writing");
//        return;
//    }
//    if(file.print(message)){
//        Serial.println("File written");
//    } else {
//        Serial.println("Write failed");
//    }
//    file.close();
//}
//
//void appendFile(fs::FS &fs, const char * path, const char * message){
//    Serial.printf("Appending to file: %s\n", path);
//
//    File file = fs.open(path, FILE_APPEND);
//    if(!file){
//        Serial.println("Failed to open file for appending");
//        return;
//    }
//    if(file.print(message)){
//        Serial.println("Message appended");
//    } else {
//        Serial.println("Append failed");
//    }
//    file.close();
//}
//
//void renameFile(fs::FS &fs, const char * path1, const char * path2){
//    Serial.printf("Renaming file %s to %s\n", path1, path2);
//    if (fs.rename(path1, path2)) {
//        Serial.println("File renamed");
//    } else {
//        Serial.println("Rename failed");
//    }
//}
//
//void deleteFile(fs::FS &fs, const char * path){
//    Serial.printf("Deleting file: %s\n", path);
//    if(fs.remove(path)){
//        Serial.println("File deleted");
//    } else {
//        Serial.println("Delete failed");
//    }
//}
//








//
//void remove_duplicate(String arr[], uint8_t len){
//
//    uint8_t i, j, k;
//
//    // use nested for loop to find the duplicate elements in array
//    for ( i = 0; i < len; i ++){
//        for ( j = i + 1; j < len; j++){
//
//            // use if statement to check duplicate element
//            if ( arr[i] == arr[j]){
//                // delete the current position of the duplicate element
//                for ( k = j; k < len - 1; k++){
//                    arr[k] = arr [k + 1];
//                }
//                // decrease the size of array after removing duplicate element
//                len--;
//
//            // if the position of the elements is changes, don't increase the index j
//                j--;
//            }
//        }
//    }
//
//
//    // for loop to print the array
//    for ( i = 0; i < len; i++){
//        Serial.println(arr[i]);
//    }
//}

//
//void setup() {
//  Serial.begin(115200);
//  delay(1000);
//  Serial.println("");
//
//  String strAr[20];
//
//  strAr[0] = "This is a test";
//  strAr[1] = "this is another test";
//  strAr[2] = "This is a third";
//
//  Serial.println(strAr[0]);
//  Serial.println(strAr[1]);
//  Serial.println(strAr[2]);
//
//  /*int len = sizeof(str)/sizeof(String);
//  for (int i = 0; i < len; i++){
//      Serial.println(arr[i]);
//  } */
//
//}
//
//void loop() {
//  // put your main code here, to run repeatedly:
//
//}
//
//
//void remove_duplicate(String arr[], uint8_t len){
//
//    uint8_t i, j, k;
//
//    // use nested for loop to find the duplicate elements in array
//    for ( i = 0; i < len; i ++){
//        for ( j = i + 1; j < len; j++){
//
//            // use if statement to check duplicate element
//            if ( arr[i] == arr[j]){
//                // delete the current position of the duplicate element
//                for ( k = j; k < len - 1; k++){
//                    arr[k] = arr [k + 1];
//                }
//                // decrease the size of array after removing duplicate element
//                len--;
//
//            // if the position of the elements is changes, don't increase the index j
//                j--;
//            }
//        }
//    }
//
//
//    // for loop to print the array
//    for ( i = 0; i < len; i++){
//        Serial.println(arr[i]);
//    }
//}

#include "FS.h"


void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  delay(1000);
  Serial.println("");
   
  if (!SPIFFS.begin()){
    Serial.println("Failed to mount file system");
    return;
  } 

  // exibir arquivos
  Dir dir = SPIFFS.openDir("/");
  while (dir.next()) {
    Serial.print(dir.fileName());
    Serial.print(" -- ");
    File f = dir.openFile("r");
    Serial.println(f.size());
  }

  // Remover arquivos
  Dir dir1 = SPIFFS.openDir("/");
  while (dir1.next()) {
    SPIFFS.remove(dir1.fileName());   
  }
}


void loop(){
  
}

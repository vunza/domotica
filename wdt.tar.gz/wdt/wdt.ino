#include <Ticker.h>

Ticker ticks;

volatile int WatchDogCount = 0;

void ISR_WatchDog(){
  WatchDogCount++;
  Serial.println(WatchDogCount);
}

void setup(){
  Serial.begin(9600);

  // Primeiro argumento é o tempo, em segundos, em que se executará "ISR_WatchDog".
  ticks.attach(1, ISR_WatchDog); 
}

void loop(){  
  Serial.println("Esperando WDT");
  delay(5000);    // Necessário para o funcionamento do WDT
  while(1);       // Este loop infinito provoca a reinicialização do ESP
}

#!/bin/sh

HA_URL="http://localhost:8123"
HA_TOKEN="Bearer <SEU_eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJjMDUwYTVkNTMzZDU0ZjBmODJlY2NjZmQyZDgwZDRlYyIsImlhdCI6MTczNjcxNzU1NSwiZXhwIjoyMDUyMDc3NTU1fQ.oLIiyFN8c4lPCAgIPL_sFEWI12P3IcsLsid4KL8A2D0"
AUTOMATION_ID="id001"
NEW_TIME="18:17:00"

# Obter automação atual
AUTOMATION_JSON=$(curl -s -X GET \
  -H "Authorization: $HA_TOKEN" \
  -H "Content-Type: application/json" \
  "$HA_URL/api/config/automation/config/$AUTOMATION_ID")

# Modificar o horário
UPDATED_JSON=$(echo "$AUTOMATION_JSON" | jq --arg new_time "$NEW_TIME" \
  '.trigger[] | select(.platform == "time" and has("at")).at = $new_time')

# Enviar atualização
curl -X PUT \
  -H "Authorization: $HA_TOKEN" \
  -H "Content-Type: application/json" \
  -d "$UPDATED_JSON" \
  "$HA_URL/api/config/automation/config/$AUTOMATION_ID"

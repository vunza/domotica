#!/bin/bash
# restore_container.sh
CONTAINER_NAME="$1"
BACKUP_DATE="$2"
BACKUP_DIR="$3"

if [ -z "$CONTAINER_NAME" ] || [ -z "$BACKUP_DATE" ]; then
    echo "Uso: $0 <nome_container> <data_backup>"
    echo "Exemplo: $0 homeassistant 20241102_1430"
    exit 1
fi

echo "🔄 Restaurando container: $CONTAINER_NAME (backup: $BACKUP_DATE)"

# Parar container se estiver rodando
docker stop "$CONTAINER_NAME" 2>/dev/null || true

# 1. Restaurar imagem
if [ -f "$BACKUP_DIR/${CONTAINER_NAME}_image_${BACKUP_DATE}.tar.gz" ]; then
    echo "🐳 Restaurando imagem..."
    docker load < "$BACKUP_DIR/${CONTAINER_NAME}_image_${BACKUP_DATE}.tar.gz"
fi

# 2. Restaurar arquivos
if [ -d "$BACKUP_DIR/${CONTAINER_NAME}_files_${BACKUP_DATE}" ]; then
    echo "📁 Restaurando arquivos..."
    
    # Recriar container se necessário
    if ! docker ps -a --format "table {{.Names}}" | grep -q "$CONTAINER_NAME"; then
        echo "❌ Container não existe. Recrie manualmente primeiro."
        exit 1
    fi
    
    # Copiar arquivos de volta
    docker cp "$BACKUP_DIR/${CONTAINER_NAME}_files_${BACKUP_DATE}/." "$CONTAINER_NAME":/
fi

# 3. Restaurar volumes
for volume_backup in "$BACKUP_DIR/${CONTAINER_NAME}_volume_"*"_${BACKUP_DATE}.tar.gz"; do
    if [ -f "$volume_backup" ]; then
        VOLUME_NAME=$(echo "$volume_backup" | sed "s|.*${CONTAINER_NAME}_volume_\(.*\)_${BACKUP_DATE}.tar.gz|\1|")
        echo "💾 Restaurando volume: $VOLUME_NAME"
        
        # Encontrar mount point do volume
        VOLUME_PATH=$(docker inspect "$CONTAINER_NAME" --format="{{range .Mounts}}{{if eq .Name \"$VOLUME_NAME\"}}{{.Source}}{{end}}{{end}}")
        
        if [ -n "$VOLUME_PATH" ]; then
            tar -xzf "$volume_backup" -C "$VOLUME_PATH"
        fi
    fi
done

# Reiniciar container
echo "🚀 Reiniciando container..."
docker start "$CONTAINER_NAME"

echo "✅ Restore completo!"
docker ps | grep "$CONTAINER_NAME"

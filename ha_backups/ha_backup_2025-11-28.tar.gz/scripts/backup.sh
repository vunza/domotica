#!/bin/bash
# backup_container.sh
CONTAINER_NAME="$1"
BACKUP_DIR="$2"
DATE=$(date +%Y%m%d_%H%M%S)

if [ -z "$CONTAINER_NAME" ]; then
    echo "Uso: $0 <nome_do_container>"
    exit 1
fi

echo "📦 Iniciando backup do container: $CONTAINER_NAME"

# Verificar se container existe
if ! docker ps -a --format "table {{.Names}}" | grep -q "$CONTAINER_NAME"; then
    echo "❌ Container não encontrado: $CONTAINER_NAME"
    exit 1
fi

# Criar diretório de backup
mkdir -p "$BACKUP_DIR"

# 1. Backup dos arquivos do container
echo "📁 Backup dos arquivos do container..."
docker cp "$CONTAINER_NAME":/ "$BACKUP_DIR/${CONTAINER_NAME}_files_${DATE}/"

# 2. Backup da imagem (commitar estado atual)
echo "🐳 Backup da imagem..."
docker commit "$CONTAINER_NAME" "${CONTAINER_NAME}_backup:${DATE}"
docker save "${CONTAINER_NAME}_backup:${DATE}" | gzip > "$BACKUP_DIR/${CONTAINER_NAME}_image_${DATE}.tar.gz"

# 3. Backup das variáveis de ambiente e configuração
echo "⚙️ Backup da configuração..."
docker inspect "$CONTAINER_NAME" > "$BACKUP_DIR/${CONTAINER_NAME}_inspect_${DATE}.json"

# 4. Backup dos volumes (se houver)
echo "💾 Backup dos volumes..."
VOLUMES=$(docker inspect "$CONTAINER_NAME" --format='{{range .Mounts}}{{.Source}} {{end}}')
if [ -n "$VOLUMES" ]; then
    for volume in $VOLUMES; do
        VOLUME_NAME=$(basename "$volume")
        tar -czf "$BACKUP_DIR/${CONTAINER_NAME}_volume_${VOLUME_NAME}_${DATE}.tar.gz" -C "$volume" .
        echo "  ✅ Volume: $VOLUME_NAME"
    done
fi

echo "✅ Backup completo salvo em: $BACKUP_DIR"
ls -la "$BACKUP_DIR" | grep "$CONTAINER_NAME"

#!/bin/bash
BROKER="192.168.0.5"

temp=$(cat /sys/class/thermal/thermal_zone0/temp)
temp_c=$(echo "scale=1; $temp / 1000" | bc)
mosquitto_pub -h "$BROKER" -t "armbian/cpu_temp" -m "$temp_c"

# Publicar uso de memória
mosquitto_pub -h "$BROKER" -t "armbian/memory_usage" -m "$(free | awk '/Mem:/ {printf "%.1f", $3/$2 * 100}')"

# Publicar uso de disco
mosquitto_pub -h "$BROKER" -t "armbian/disk_usage" -m "$(df / --output=pcent | tail -n 1 | tr -d '%')"


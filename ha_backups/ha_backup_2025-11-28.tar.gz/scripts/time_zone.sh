#!/bin/bash

sudo timedatectl set-timezone Africa/Luanda
sudo ntpdate pool.ntp.org


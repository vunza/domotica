import serial
import time

# Configure the serial port
# Replace 'COMx' with your actual serial port (e.g., 'COM3' on Windows, '/dev/ttyUSB0' on Linux)
# Set the baud rate to match your device
#ser = serial.Serial('usb-1a86_USB_Serial-if00-port0', 115200, timeout=1)
ser = serial.Serial('/dev/ttyUSB1', 115200, timeout=1)

print(f"Connected to: {ser.portstr}")

try:
    while True:
        message_to_send = b"STATUS?\n" 
        ser.write(message_to_send)
        time.sleep(2)
    # Read a line until a newline character ('\n') is encountered
    # The data will be in bytes, so decode it to a string
        line = ser.readline().decode('utf-8').strip()
        if line:
            print(f"Received: {line}")
        time.sleep(0.1) # Small delay to prevent busy-waiting
except KeyboardInterrupt:
    print("Exiting...")
finally:
    ser.close()
    print("Serial port closed.")





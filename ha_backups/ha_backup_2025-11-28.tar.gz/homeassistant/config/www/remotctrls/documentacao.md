# Comentário 1

## Comentário 2

```js
// Criar tabela com os hubs IR encontrados
criarTabelaRapida(hubsData, 'div_ctrl_r_wrappper');
```

[ACITE](https://www.acite.ao)

***___Italico_Negrito___***



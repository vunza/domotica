# var_nome = data.get("Nome")
# logger.error(f"Olá, {var_nome}!")

# var_entidade = data.get("Entidade")
# var_estado = hass.states.get(var_entidade).state
# logger.error(var_entidade + " -- " + var_estado)



# TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJjMDUwYTVkNTMzZDU0ZjBmODJlY2NjZmQyZDgwZDRlYyIsImlhdCI6MTczNjcxNzU1NSwiZXhwIjoyMDUyMDc3NTU1fQ.oLIiyFN8c4lPCAgIPL_sFEWI12P3IcsLsid4KL8A2D0" 

'''
import requests

# Configurações
HA_URL = "http://192.168.0.5:8123"

# Publicar mensagem MQTT
def publish_mqtt(topic, message):
    url = f"{HA_URL}/api/services/mqtt/publish"
    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "topic": topic,
        "payload": message
    }
    response = requests.post(url, json=payload, headers=headers)
    return response.json()

# Exemplo de uso
publish_mqtt("zigbee2mqtt/0xf082c0fffeedf8c4/set", '{"learn_ir_code":"ON"}')
'''

'''
import requests
import os

# Aceder às variáveis de ambiente
HA_TOKEN = os.getenv('HA_TOKEN')
HA_URL = os.getenv('HA_URL')

token = HA_TOKEN
url = f"{HA_URL}/api/states"

headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

response = requests.get(url, headers=headers)
print(response.json())'''



import os

# Caminho do arquivo no diretório www
TOKEN_FILE = '/config/www/token_api.txt'

# Pegar variáveis de ambiente
HA_TOKEN = os.getenv('HA_TOKEN')

with open(TOKEN_FILE, 'w') as f:
    if HA_TOKEN:
        f.write(HA_TOKEN)
    else:
        f.write('Token não configurado')

print(HA_TOKEN)    








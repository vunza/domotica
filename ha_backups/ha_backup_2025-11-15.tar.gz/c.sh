#!/bin/bash

# Script para sincronizar o relógio com servidores NTP até obter sucesso

MAX_TENTATIVAS=10
INTERVALO=5  # segundos entre tentativas

echo "Iniciando sincronização de horário com NTP..."

for (( tentativa=1; tentativa<=MAX_TENTATIVAS; tentativa++ ))
do
    echo "Tentativa $tentativa de $MAX_TENTATIVAS..."
    
    # Executa o ntpdate e captura a saída
    resultado=$(sudo ntpdate pool.ntp.org 2>&1)
    
    # Verifica se a sincronização foi bem-sucedida
    if [[ $resultado == *"adjust time"* ]]; then
        echo -e "\n✅ Sincronização bem-sucedida!"
        echo "$resultado"
        exit 0
    else
        echo "Falha na tentativa $tentativa. Tentando novamente em $INTERVALO segundos..."
        echo "$resultado"
        sleep $INTERVALO
    fi
done

echo -e "\n❌ Falha após $MAX_TENTATIVAS tentativas. Verifique sua conexão de rede."
exit 1

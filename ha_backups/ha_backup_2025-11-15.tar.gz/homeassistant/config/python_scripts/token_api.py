import os
import json
from datetime import datetime

# Executar automaticamente quando o HA inicia
def get_token_info():
    HA_TOKEN = os.getenv('HA_TOKEN')
    token_data = {
        'token': HA_TOKEN,
        'timestamp': datetime.now().isoformat()
    }
    
    with open('/config/www/json_files/token_api.json', 'w') as f:
        json.dump(token_data, f, indent=2)

# Executar sempre que o script é carregado
get_token_info()
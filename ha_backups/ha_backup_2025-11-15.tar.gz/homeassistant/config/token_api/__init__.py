import os
import logging
from homeassistant.components.http import HomeAssistantView

_LOGGER = logging.getLogger(__name__)

class TokenView(HomeAssistantView):
    """View para servir o token."""

    url = '/api/token'
    name = 'api:token'
    requires_auth = False  # Aviso: deixar como True em produção!

    async def get(self, request):
        """Retorna o token."""
        token = os.getenv('HA_TOKEN')
        if token:
            return self.json({'token': token})
        else:
            return self.json({'error': 'Token not found'}, status_code=404)

async def async_setup(hass, config):
    """Configurar o componente."""
    hass.http.register_view(TokenView)
    return True

# Vendored MicroPyton libraries

This directory contains some libraries that are required by examples and unit
tests.

All libraries except `utemplate` were copied from the
[micropython-lib](https://github.com/micropython/micropython-lib) project. See
the README file in the `common/utemplate` subdirectory for details about this
library.

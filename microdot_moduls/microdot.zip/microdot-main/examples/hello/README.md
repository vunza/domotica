This directory contains several "Hello, World!" type examples for different
platforms and configurations supported by Microdot.

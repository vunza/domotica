This directory contains file upload examples.

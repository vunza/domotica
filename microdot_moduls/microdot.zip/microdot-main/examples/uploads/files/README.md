Uploaded files are saved to this directory.

This directory contains Cross-Origin Resource Sharing (CORS) examples.

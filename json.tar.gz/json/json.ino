#include <ArduinoJson.h>

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("");
  Serial.println("");
  
  // Create object, texto com formato json, serialização
  DynamicJsonDocument doc_tx(1024);

  doc_tx["sensor"] = "gps";
  doc_tx["time"]   = 1351824120;
  doc_tx["data"][0] = 48.756080;
  doc_tx["data"][1] = 2.302038;

  String szJSON;
  serializeJson(doc_tx, szJSON);

  Serial.println(szJSON);
  Serial.println("");

  // Read  object, deserialização
  //char json[] = "{\"sensor\":\"gps\",\"time\":1351824120,\"data\":[48.756080,2.302038]}";

  char buff[1024];
  int var_len = szJSON.length() + 1;
  szJSON.toCharArray(buff, var_len);
  
  DynamicJsonDocument doc_rx(1024);
  deserializeJson(doc_rx, buff);
  
  const char* sensor = doc_rx["sensor"];
  long time          = doc_rx["time"];
  double latitude    = doc_rx["data"][0];
  double longitude   = doc_rx["data"][1];

  Serial.println(sensor);
  Serial.println(time);
  Serial.println(latitude);
  Serial.println(longitude);
  
}


void loop() {
  
}
